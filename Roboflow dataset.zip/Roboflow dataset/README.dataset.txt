# My First Project > 2025-08-25 12:48pm
https://universe.roboflow.com/yolodata-rarag/my-first-project-uukke

Provided by a Roboflow user
License: CC BY 4.0

